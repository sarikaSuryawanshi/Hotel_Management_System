package hotel.management.system;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.util.Date;

public class CheckOut extends JFrame implements ActionListener
{
	Choice coust;
	JLabel checkout,lblroomnumber,lblcheckintime;
	JButton bcheck,back;
	public CheckOut()
	{
		getContentPane().setBackground(Color.white);
		setLayout(null);
		
		JLabel text=new JLabel("CHECK OUT");
		text.setBounds(100,20,100,30);
		text.setForeground(Color.BLUE);
		text.setFont(new Font("tahoma",Font.PLAIN,16));
		add(text);
		
		JLabel lblid=new JLabel("Coustomer ID");
		lblid.setBounds(30,80,100,30);
		add(lblid);
		
		coust=new Choice();
		coust.setBounds(150,80,150,25);
		add(coust);
		 
		 
		 
		
		 	ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons//tick.png"));
		 	Image i2=i1.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);//crop image
			ImageIcon i3=new ImageIcon(i2);
			JLabel image=new JLabel(i3);
			image.setBounds(310,80,20,20);
			add(image);
			
			
			JLabel lblroomno=new JLabel("ROOM NO");
			lblroomno.setBounds(30,130,100,30);
			add(lblroomno);
			
			lblroomnumber=new JLabel();
			lblroomnumber.setBounds(200,130,100,30);
			add(lblroomnumber);
			
			JLabel checktime=new JLabel("CHECKIN TIME");
			checktime.setBounds(30,180,100,30);
			add(checktime);
			
			lblcheckintime=new JLabel();
			lblcheckintime.setBounds(150,180,100,30);
			add(lblcheckintime);
			
			
			JLabel checkouttime=new JLabel("Checkout Time");
			checkouttime.setBounds(30,230,100,30);
			add(checkouttime);
			
			Date date=new Date();
			checkout=new JLabel(""+date);
			checkout.setBounds(150,230,150,30);
			add(checkout);
			
			
			
			bcheck=new JButton("CHECK OUT");
			bcheck.setBounds(30, 280, 120, 30);
			bcheck.addActionListener(this);
			bcheck.setBackground(Color.BLACK);
			bcheck.setForeground(Color.WHITE);
			add(bcheck);
			
			back=new JButton("BACK");
			back.setBounds(170, 280, 120, 30);
			back.addActionListener(this);
			back.setBackground(Color.BLACK);
			back.setForeground(Color.WHITE);
			add(back);
			try 
			 {
				 conn c=new conn();
					ResultSet rs=c.s.executeQuery("select * from coustomer");
					while(rs.next())
					{
						coust.add(rs.getString("number"));
						lblroomnumber.setText(rs.getString("room"));
						lblcheckintime.setText(rs.getString("checkintime"));
						
					}	
					
			 }
			 catch(Exception e)
			 {
				 e.printStackTrace();
			 }
			
			
			ImageIcon i4=new ImageIcon(ClassLoader.getSystemResource("icons//sixth.jpg"));
		 	Image i5=i4.getImage().getScaledInstance(400, 250, Image.SCALE_DEFAULT);//crop image
			ImageIcon i6=new ImageIcon(i5);
			JLabel image1=new JLabel(i6);
			image1.setBounds(350,50,400,250);
			add(image1);
		
		setBounds(300,200,800,400);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==bcheck)
		{
			
			
			try 
			{
				String query1=
						"delete from coustomer where number='"+coust.getSelectedItem()+"'";
				String query2=
					"update room set availability='available' where roomnumber='"+lblroomnumber.getText()+"'";
				
				
				conn con=new conn();
				con.s.executeUpdate(query1);
				con.s.executeUpdate(query2);
				
				
				System.out.println(lblroomnumber.getText());
				JOptionPane.showMessageDialog(null,"CHECk-OUT DONE....!");
				setVisible(false);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		else
			if(ae.getSource()==back)
			{
				setVisible(false);
				new Reception();
			}
		
	}
	public static void main(String args[])
	{
		new CheckOut();
	}
	
}
