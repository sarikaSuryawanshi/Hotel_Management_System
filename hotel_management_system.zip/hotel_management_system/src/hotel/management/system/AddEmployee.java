package hotel.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class AddEmployee extends JFrame implements ActionListener
{
	JTextField tfname,tfage,tfphone,tfemail,tfsalary,tfaadhar;
	JRadioButton rbmale,rbfemale;
	JLabel lblname,lblage,lbljob,lblphone,lblemail,lblsalary,lblgender,lblaadhar;
	JButton submit;
	JComboBox cbjob;
	public AddEmployee()
	{
		setLayout(null);
		
		lblname=new JLabel("NAME");
		lblname.setBounds(60,30,120,30);
		lblname.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblname);
		
		tfname=new JTextField();
		tfname.setBounds(200,30,150,30);
		add(tfname);
		
		
		lblage=new JLabel("AGE");
		lblage.setBounds(60,80,120,30);
		lblage.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblage);
		
		tfage=new JTextField();
		tfage.setBounds(200,80,150,30);
		add(tfage);
		
		lblgender=new JLabel("GENDER");
		lblgender.setBounds(60,130,120,30);
		lblgender.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblgender);
		
		rbmale=new JRadioButton("MALE");
		rbmale.setFont(new Font("tahoma",Font.PLAIN,14));
		rbmale.setBackground(Color.white);
		rbmale.setBounds(200,130,70,30);
		add(rbmale);
		
		rbfemale=new JRadioButton("FEMALE");
		rbfemale.setFont(new Font("tahoma",Font.PLAIN,14));
		rbfemale.setBackground(Color.white);
		rbfemale.setBounds(270,130,90,30);
		add(rbfemale);
		
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(rbfemale);
		bg.add(rbmale);
		
		
		lbljob=new JLabel("JOB");
		lbljob.setBounds(60,180,120,30);
		lbljob.setFont(new Font("Tahoma",Font.PLAIN,17));
				add(lbljob);
		
		
		String str[]={"Front Desk Colors","Porters","HouseKeeping","KitchenStaff","RooomService","Chiefs","waiter","Manager","Accountant"};
		cbjob=new JComboBox(str);
		cbjob.setBounds(200,180,150,30);
		cbjob.setBackground(Color.white);
		add(cbjob);
		
		
		lblsalary=new JLabel("SALARY");
		lblsalary.setBounds(60,230,120,30);
		lblsalary.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblsalary);
		
		tfsalary=new JTextField();
		tfsalary.setBounds(200,230,150,30);
		add(tfsalary);
		
		
		lblphone=new JLabel("PHONE NO");
		lblphone.setBounds(60,280,120,30);
		lblphone.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblphone);
		
		tfphone=new JTextField();
		tfphone.setBounds(200,280,150,30);
		add(tfphone);
		
		lblemail=new JLabel("EMAIL ID");
		lblemail.setBounds(60,330,120,30);
		lblemail.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblemail);
		
		tfemail=new JTextField();
		tfemail.setBounds(200,330,150,30);
		add(tfemail);
		
		
		
		lblaadhar=new JLabel("AADHAR NO");
		lblaadhar.setBounds(60,380,120,30);
		lblaadhar.setFont(new Font("Tahoma",Font.PLAIN,17));
		add(lblaadhar);
		
		tfaadhar=new JTextField();
		tfaadhar.setBounds(200,380,150,30);
		add(tfaadhar);
		
		
		submit=new JButton("SUBMIT");
		submit.setBackground(Color.black);
		submit.setForeground(Color.WHITE);
		submit.addActionListener(this);
		submit.setBounds(200,430,150,30);
		add(submit);
		
		
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons//tenth.jpg"));
		Image i2=i1.getImage().getScaledInstance(450, 450, Image.SCALE_DEFAULT);//crop image
		ImageIcon i3=new ImageIcon(i2);
		JLabel image=new JLabel(i3);
		image.setBounds(380,60,450,370);
		add(image);
		
		
		setBounds(350,200,850,540);
		getContentPane().setBackground(Color.white);
		setVisible(true);
		
		
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		
		String name=tfname.getText();
		String age=tfage.getText();
		String salary=tfsalary.getText();
		String phone=tfphone.getText();
		String email=tfemail.getText();
		String aadhar=tfaadhar.getText();
		
		
		String gender=null;
		
		
		if(name.equals(""))
		{
			JOptionPane.showMessageDialog(null, "Name Should Not be Empty");
			return;
		}
		if(rbmale.isSelected())
		{
			gender="MALE";
		}
		else
		if(rbfemale.isSelected())
		{
			gender="FEMALE";
		}
		
		
		String job=(String)cbjob.getSelectedItem();//typecasting in string because getselecteditem it return a onject
		try
		{
			conn conn=new conn();
			String query="insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+email+"','"+aadhar+"')";
			conn.s.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Employee Added Successfully...!");
			setVisible(false);
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	public static void main(String args[])
	{
		new AddEmployee();
	}
	
}
