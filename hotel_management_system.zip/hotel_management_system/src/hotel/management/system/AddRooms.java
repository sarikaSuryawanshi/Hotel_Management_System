package hotel.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddRooms extends JFrame implements ActionListener
{
	JButton addroom,cancl;
	JComboBox avalaiblecombo,cleancombo,typecombo;
	JLabel heading,lblroomno,lblavailable,lblclean,lblprice,lbltype;
	JTextField tfroom,tfprice;
	public AddRooms ()
	{
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		
		
		heading=new JLabel("ADD ROOMS");
		heading.setFont(new Font("Tahoma",Font.BOLD,18));
		heading.setBounds(150,20,200,20);
		add(heading);
		
		
		lblroomno=new JLabel("ROOM NUMBER");
		lblroomno.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblroomno.setBounds(60,80,120,30);
		add(lblroomno);
		
		tfroom=new JTextField();
		tfroom.setBounds(200,80,150,30);
		add(tfroom);
		
		
		lblavailable=new JLabel("AVAILABLE");
		lblavailable.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblavailable.setBounds(60,130,120,30);
		add(lblavailable);
		
		String availableoptions[]= {"Available","Occupied"};
		avalaiblecombo =new JComboBox(availableoptions);
		avalaiblecombo.setBounds(200,130,150,30);
		avalaiblecombo.setBackground(Color.WHITE);
		add(avalaiblecombo);
		
		
		
		
		lblclean=new JLabel("Cleaning Status");
		lblclean.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblclean.setBounds(60,180,120,30);
		add(lblclean);
		
		String cleaningptions[]= {"Clean","Dirty"};
		cleancombo =new JComboBox(cleaningptions);
		cleancombo.setBounds(200,180,150,30);
		cleancombo.setBackground(Color.WHITE);
		add(cleancombo);
		
		
		
		
		
		lblprice=new JLabel("PRICE");
		lblprice.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblprice.setBounds(60,230,120,30);
		add(lblprice);
		
		tfprice=new JTextField();
		tfprice.setBounds(200,230,150,30);
		add(tfprice);
		
		
		
		lbltype=new JLabel("BED TYPE");
		lbltype.setFont(new Font("Tahoma",Font.PLAIN,16));
		lbltype.setBounds(60,280,120,30);
		add(lbltype);
		
		
		
		String typeptions[]= {"Single Bed","Double bed"};
		typecombo=new JComboBox(typeptions);
		typecombo.setBounds(200,280,150,30);
		typecombo.setBackground(Color.WHITE);
		add(typecombo);
		
		
		
		addroom=new JButton("ADD ROOM");
		addroom.setBackground(Color.black);
		addroom.setForeground(Color.WHITE);
		addroom.addActionListener(this);
		addroom.setBounds(60,350,130,30);
		add(addroom);
		
		cancl=new JButton("CANCEL");
		cancl.setBounds(220, 350, 130, 30);
		cancl.addActionListener(this);
		cancl.setBackground(Color.BLACK);
		cancl.setForeground(Color.WHITE);
		add(cancl);
		
		
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons//twelve.jpg"));
		JLabel image=new JLabel(i1);
		image.setBounds(400,30,500,300);
		add(image);
		
		
		
		setBounds(330,200,940,470);
		setVisible(true);
		
		
		
		
		
			
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==addroom)
		{
			String roomnumber=tfroom.getText();
			String availability= (String )avalaiblecombo.getSelectedItem(); 
			String cleaning_status=(String)cleancombo.getSelectedItem();
			String price=tfprice.getText();
			String bed_type=(String)typecombo.getSelectedItem();
			
			try 
			{
				conn conn=new conn();
				String str="insert into room values('"+roomnumber+"','"+availability+"','"+cleaning_status+"','"+price+"','"+bed_type+"')";
				conn.s.executeUpdate(str);
				
				
				JOptionPane.showMessageDialog(null,"New Room Added SuccessFully.....!");
				setVisible(false);
			}
			catch(Exception ae)
			{
				ae.printStackTrace();
			}
			
		}
		else
		{
			setVisible(false);
		}
		
	}
	

	public static void main(String[] args) 
	{
		new AddRooms ();

	}





	

}
