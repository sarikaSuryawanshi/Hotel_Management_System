package hotel.management.system;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Reception extends JFrame implements ActionListener
{
	JButton newcoust,rooms,department,allemp,allcoust,managerinfo,
	checkout,pdtatus,rtatus,pickup,searchroom,logout;
	public Reception()
	{
		
		setLayout(null);
		getContentPane().setBackground(Color.WHITE);
		
		newcoust=new JButton(" NEW COUSTOMER FORM");
		newcoust.setBackground(Color.black);
		newcoust.setForeground(Color.WHITE);
		newcoust.addActionListener(this);
		newcoust.setBounds(10,30,200,30);
		add(newcoust);
		
		
		rooms=new JButton("ROOMS ");
		rooms.setBackground(Color.black);
		rooms.setForeground(Color.WHITE);
		rooms.addActionListener(this);
		rooms.setBounds(10,70,200,30);
		add(rooms);
		
		department=new JButton("DEPARTMENT");
		department.setBackground(Color.black);
		department.setForeground(Color.WHITE);
		department.addActionListener(this);
		department.setBounds(10,110,200,30);
		add(department);
		
		allemp=new JButton("ALL EMPLOYEE");
		allemp.setBackground(Color.black);
		allemp.setForeground(Color.WHITE);
		allemp.addActionListener(this);
		allemp.setBounds(10,150,200,30);
		add(allemp);
		
		allcoust=new JButton("COUSTOMER INFO");
		allcoust.setBackground(Color.black);
		allcoust.setForeground(Color.WHITE);
		allcoust.addActionListener(this);
		allcoust.setBounds(10,190,200,30);
		add(allcoust);
		
		
		managerinfo=new JButton("MANAGER INFO");
		managerinfo.setBackground(Color.black);
		managerinfo.setForeground(Color.WHITE);
		managerinfo.addActionListener(this);
		managerinfo.setBounds(10,230,200,30);
		add(managerinfo);
		
		
		checkout=new JButton("CHECK OUT");
		checkout.setBackground(Color.black);
		checkout.setForeground(Color.WHITE);
		checkout.addActionListener(this);
		checkout.setBounds(10,270,200,30);
		add(checkout);
		
		
		pdtatus=new JButton("UPDATE STATUS");
		pdtatus.setBackground(Color.black);
		pdtatus.setForeground(Color.WHITE);
		pdtatus.addActionListener(this);
		pdtatus.setBounds(10,310,200,30);
		add(pdtatus);
		
		rtatus=new JButton("UPDATE ROOM STATUS");
		rtatus.setBackground(Color.black);
		rtatus.setForeground(Color.WHITE);
		rtatus.addActionListener(this);
		rtatus.setBounds(10,350,200,30);
		add(rtatus);
		
		pickup=new JButton("PICKUP SERVICE");
		pickup.setBackground(Color.black);
		pickup.setForeground(Color.WHITE);
		pickup.addActionListener(this);
		pickup.setBounds(10,390,200,30);
		add(pickup);
		
		searchroom=new JButton("SEARCH ROOM");
		searchroom.setBackground(Color.black);
		searchroom.setForeground(Color.WHITE);
		searchroom.addActionListener(this);
		searchroom.setBounds(10,430,200,30);
		add(searchroom);
		
		logout=new JButton("LOG OUT");
		logout.setBackground(Color.black);
		logout.setForeground(Color.WHITE);
		logout.addActionListener(this);
		logout.setBounds(10,470,200,30);
		add(logout);
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons//fourth.jpg"));
		JLabel image=new JLabel(i1);
		image.setBounds(250,30,500,470);
		add(image);
		
	
		setBounds(350,200,800,570);
		setVisible(true);
	}

	
	@Override
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==newcoust)
		{
			setVisible(false);
			new addcoustmer();
		}
		else
		if(ae.getSource()==rooms)
		{
			setVisible(false);
			new Room();
		}
		else
			if(ae.getSource()==department)
			{
				setVisible(false);
				new Department();
			}
			else
				if(ae.getSource()==allemp)
				{
					setVisible(false);
					new AllEmp();
				}
				else
					if(ae.getSource()==allcoust)
					{
						setVisible(false);
						new CoustInfo();
					}
					else
						if(ae.getSource()==managerinfo)
						{
							setVisible(false);
							new ManagerInfo();
						}
						else
							if(ae.getSource()==searchroom)
							{
								setVisible(false);
								new SearchRoom();
							}
							else
								if(ae.getSource()==pdtatus)
								{
									setVisible(false);
									new UpdateCheck();
								}
								else
								if(ae.getSource()==rtatus)
								{
									setVisible(false);
									new UpdateRoom();
								}
								else
									if(ae.getSource()==pickup)
									{
										setVisible(false);
										new PickupService();
									}
									else
										if(ae.getSource()==checkout)
										{
											setVisible(false);
											new CheckOut();
										}
										else
											if(ae.getSource()==logout)
											{
												setVisible(false);
												//new CheckOut();
											}

			
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Reception();
	}

	

}
