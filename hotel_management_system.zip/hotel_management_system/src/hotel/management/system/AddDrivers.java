package hotel.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddDrivers extends JFrame implements ActionListener
{
	JButton adddriver,cancl;
	JComboBox gendercombo,avalaiblecombo ;
	JLabel lblname,lblheading,lblage,lblgender,lblcomp,lblmodel,lblavalaible,lblloc;
	JTextField tfname,tfage,tfcomp,tfmodel,tfloc;
	public AddDrivers ()
	{
		
		
		
		
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		
		
		lblheading=new JLabel("ADD DRIVERS");
		lblheading.setFont(new Font("Tahoma",Font.BOLD,18));
		lblheading.setBounds(150,10,200,20);
		add(lblheading);
		
		
		lblname=new JLabel("NAME");
		lblname.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblname.setBounds(60,70,120,30);
		add(lblname);
		
		tfname=new JTextField();
		tfname.setBounds(200,72,150,30);
		add(tfname);
		
		
		lblage=new JLabel("AGE");
		lblage.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblage.setBounds(60,110,120,30);
		add(lblage);
		
		
		tfage=new JTextField();
		tfage.setBounds(200,110,150,30);
		add(tfage);
		
		
		
		lblgender=new JLabel("GENDER");
		lblgender.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblgender.setBounds(60,150,120,30);
		add(lblgender);
		
		String genderoptions[]= {"MALE","FEMALE"};
		gendercombo =new JComboBox(genderoptions);
		gendercombo.setBounds(200,150,150,30);
		gendercombo.setBackground(Color.WHITE);
		add(gendercombo);
		
		
		

		lblcomp=new JLabel("CAR COMP");
		lblcomp.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblcomp.setBounds(60,190,120,30);
		add(lblcomp);
		
		
		tfcomp=new JTextField();
		tfcomp.setBounds(200,190,150,30);
		add(tfcomp);
		
		
		lblmodel=new JLabel("CAR MODEL");
		lblmodel.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblmodel.setBounds(60,230,120,30);
		add(lblmodel);
		
		
		tfmodel=new JTextField();
		tfmodel.setBounds(200,230,150,30);
		add(tfmodel);
		
		lblavalaible=new JLabel("AVALABILITY");
		lblavalaible.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblavalaible.setBounds(60,270,120,30);
		add(lblavalaible);
		
		String availableoptions[]= {"Available","BUSY"};
		avalaiblecombo =new JComboBox(availableoptions);
		avalaiblecombo.setBounds(200,270,150,30);
		avalaiblecombo.setBackground(Color.WHITE);
		add(avalaiblecombo);
		
		lblloc = new JLabel("LOCATION");
		lblloc.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblloc.setBounds(60,310,120,30);
		add(lblloc);
		
		
		tfloc=new JTextField();
		tfloc.setBounds(200,310,150,30);
		add(tfloc);
		
		
		adddriver=new JButton("ADD DRIVER");
		adddriver.setBackground(Color.black);
		adddriver.setForeground(Color.WHITE);
		adddriver.addActionListener(this);
		adddriver.setBounds(60,370,130,30);
		add(adddriver);
		
		cancl=new JButton("CANCEL");
		cancl.setBounds(220, 370, 130, 30);
		cancl.addActionListener(this);
		cancl.setBackground(Color.BLACK);
		cancl.setForeground(Color.WHITE);
		add(cancl);
		
		
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons//eleven.jpg"));
		Image i2=i1.getImage().getScaledInstance(500, 300, Image.SCALE_DEFAULT);//crop image
		ImageIcon i3=new ImageIcon(i2);
		JLabel image=new JLabel(i3);
		image.setBounds(400,30,500,300);
		add(image);
		
		
		
		
		
		setBounds(300,200,980,470);
		setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		
		
		if(e.getSource()==adddriver)
		{
			String name=tfname.getText();
			String age= tfage.getText();
			String gender=(String)gendercombo.getSelectedItem();
			String company=tfcomp.getText();
			String brand=tfmodel.getText();
			String available=(String)avalaiblecombo.getSelectedItem();;
			String location=tfloc.getText();
			
			try 
			{
				conn conn=new conn();
				String str="insert into drivers values('"+name+"','"+age+"','"+gender+"','"+company+"','"+brand+"','"+available+"','"+location+"')";
				conn.s.executeUpdate(str);
				
				
				JOptionPane.showMessageDialog(null,"New Driver Added SuccessFully.....!");
				setVisible(false);
			}
			catch(Exception ae)
			{
				ae.printStackTrace();
			}
			
		}
		else
		{
			setVisible(false);
		}
		
		
		
	}
	public static void main(String args[])
	{
		new AddDrivers();
	}





	
}
