package hotel.management.system;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;

import net.proteanit.sql.DbUtils;

public class PickupService extends JFrame implements ActionListener
{
	JButton back,submit;
	JTable table;
	Choice cartype;
	JCheckBox Available;
	
	public PickupService()
	{
		getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		
		JLabel heading=new JLabel("Pick-up Service");
		heading.setFont(new Font("Tahoma",Font.PLAIN,20));
		heading.setBounds(400,30,200,30);
		add(heading);
		
		JLabel lblbed=new JLabel("TYPE OF CAR");
		lblbed.setBounds(50,100,100,20);
		add(lblbed);
		
		
		cartype=new Choice();
		cartype.setBounds(150,100,200,25);
		add(cartype);
		
		try
		{
			conn con=new conn();
			ResultSet rs=con.s.executeQuery("select * from drivers");
			while(rs.next())
			{
				cartype.add(rs.getString("brand"));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		JLabel l1=new JLabel("Name");
		l1.setBounds(30,160,100,20);
		add(l1);
		
		JLabel l2=new JLabel("AGE");
		l2.setBounds(200,160,100,20);
		add(l2);
		
		JLabel l3=new JLabel("GENDER");
		l3.setBounds(330,160,100,20);
		add(l3);
		
		JLabel l4=new JLabel("COMPANY");
		l4.setBounds(460,160,100,20);
		add(l4);
		
		JLabel l5=new JLabel("BRAND");
		l5.setBounds(630,160,100,20);
		add(l5);
		
		
		JLabel l6=new JLabel("Availability");
		l6.setBounds(740,160,100,20);
		add(l6);
		
		JLabel l7=new JLabel("LOCATION");
		l7.setBounds(880,160,100,20);
		add(l7);
		
		table=new JTable();
		table.setBounds(0,200,1000,300);
		add(table);
		
		
		try {
			conn c=new conn();
			ResultSet rs=c.s.executeQuery("select * from drivers ");
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			
		}
		catch(Exception ae)
		{
			
			ae.printStackTrace();
			
		}
		
		submit=new JButton("SUBMIT");
		submit.setBounds(300, 520, 120, 30);
		submit.addActionListener(this);
		submit.setBackground(Color.BLACK);
		submit.setForeground(Color.WHITE);
		add(submit);
		
		back=new JButton("BACK");
		back.setBounds(500, 520, 120, 30);
		back.addActionListener(this);
		back.setBackground(Color.BLACK);
		back.setForeground(Color.WHITE);
		add(back);
		
		setBounds(300,200,1000,600);
		setVisible(true);
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		
		if(e.getSource()==submit)
		{
			try 
			{
				String query="select * from drivers where brand='"+cartype.getSelectedItem()+"'";
				
				conn con=new conn();
				ResultSet rs;
				rs=con.s.executeQuery(query);
				table.setModel(DbUtils.resultSetToTableModel(rs));
					
			}
			catch(Exception ae)
			{
				ae.printStackTrace();
			}
		}
		else
			if(e.getSource()==back)
			{
				setVisible(false);
				new Reception();
			}
	}

	public static void main(String[] args) 
	{
		new PickupService();
	}

	

}

